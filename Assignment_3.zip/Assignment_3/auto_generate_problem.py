from unified_planning.shortcuts import *
from unified_planning.io import PDDLWriter

# -----------------------------
# Load Blocks from VLM Output
# -----------------------------
vlm_blocks = ["b0", "b1", "b2"]  # Simulating output from CLIP

# -----------------------------
# Create Problem
# -----------------------------
problem = Problem("auto_droid_problem")

# Define type
block = UserType("block")

# Add objects
blocks = {}
for name in vlm_blocks:
    blocks[name] = Object(name, block)
    problem.add_object(blocks[name])

# -----------------------------
# Define Fluents
# -----------------------------
on = Fluent("on", BoolType(), x=block, y=block)
ontable = Fluent("ontable", BoolType(), x=block)
clear = Fluent("clear", BoolType(), x=block)
handempty = Fluent("handempty", BoolType())

problem.add_fluent(on)
problem.add_fluent(ontable)
problem.add_fluent(clear)
problem.add_fluent(handempty)

# -----------------------------
# Initial State (Auto-generated)
# -----------------------------
problem.set_initial_value(ontable(blocks["b0"]), True)
problem.set_initial_value(ontable(blocks["b1"]), True)
problem.set_initial_value(on(blocks["b2"], blocks["b1"]), True)
problem.set_initial_value(clear(blocks["b0"]), True)
problem.set_initial_value(clear(blocks["b2"]), True)
problem.set_initial_value(handempty(), True)

# -----------------------------
# Goal State (Auto-generated)
# -----------------------------
problem.add_goal(on(blocks["b0"], blocks["b1"]))
problem.add_goal(on(blocks["b1"], blocks["b2"]))

# -----------------------------
# Export to PDDL
# -----------------------------
writer = PDDLWriter(problem)
writer.write_domain("auto_domain.pddl")
writer.write_problem("auto_problem.pddl")

print("✅ Auto-generated PDDL files created:")
print(" - auto_domain.pddl")
print(" - auto_problem.pddl")
