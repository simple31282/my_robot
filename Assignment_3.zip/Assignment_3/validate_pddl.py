from unified_planning.io import PDDLReader

domain_path = "droid_blocks_domain.pddl"
problem_path_1= "problem_1.pddl"
problem_path_2= "problem_2.pddl"
problem_path_3= "problem_3.pddl"

reader = PDDLReader()

print("✅ Loading Domain and Problem...")

problem_1 = reader.parse_problem(domain_path, problem_path_1)
problem_2 = reader.parse_problem(domain_path,problem_path_2)
problem_3 = reader.parse_problem(domain_path,problem_path_3)


print("✅ Domain and Problems parsed successfully!")
print("Objects:", problem_1.all_objects)
print("Predicates:", problem_1.fluents)

print("Objects:", problem_2.all_objects)
print("Predicates:", problem_2.fluents)

print("Objects:", problem_3.all_objects)
print("Predicates:", problem_3.fluents)
