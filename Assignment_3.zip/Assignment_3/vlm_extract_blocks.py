import clip
import torch
import cv2
from PIL import Image

device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)

classes = ["red block", "blue block", "green block", "yellow block"]

def detect_blocks(image_path):
    image = preprocess(Image.open(image_path)).unsqueeze(0).to(device)
    text = clip.tokenize(classes).to(device)

    with torch.no_grad():
        image_features = model.encode_image(image)
        text_features = model.encode_text(text)

        similarity = (100.0 * image_features @ text_features.T).softmax(dim=-1)

    detected = []
    for i, score in enumerate(similarity[0]):
        if score > 0.25:
            detected.append(classes[i])

    return detected

# TEST
if __name__ == "__main__":
    blocks = detect_blocks("droid_image_01.png")
    print("Detected blocks:", blocks)
