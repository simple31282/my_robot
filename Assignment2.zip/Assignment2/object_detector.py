import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

# -------------------------------
# SAFE OPTIONAL IMPORTS
# -------------------------------
TORCH_AVAILABLE = True
try:
    import torch
    import torchvision.transforms as T
    import torchvision
except Exception as e:
    TORCH_AVAILABLE = False
    print(f"⚠️  TORCH NOT AVAILABLE: {e}")

PSYCOPG_AVAILABLE = True
try:
    import psycopg2
except Exception as e:
    PSYCOPG_AVAILABLE = False
    print(f"⚠️  PSYCOPG2 NOT AVAILABLE: {e}")


class ObjectDetector(Node):
    def __init__(self):
        super().__init__('object_detector')

        self.bridge = CvBridge()

        # ✅ Subscribe to camera
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )

        self.get_logger().info("✅ Subscribed to /camera/image_raw")

        # -------------------------------
        # LOAD MODEL (ONLY IF TORCH WORKS)
        # -------------------------------
        self.model = None
        self.transform = None

        if TORCH_AVAILABLE:
            self.get_logger().info("✅ Loading COCO pretrained FasterRCNN model...")
            self.model = torchvision.models.detection.fasterrcnn_resnet50_fpn(weights="DEFAULT")
            self.model.eval()
            self.transform = T.Compose([T.ToTensor()])
            self.get_logger().info("✅ Object Detector READY")
        else:
            self.get_logger().error("❌ PyTorch NOT available. Detection DISABLED.")

        # -------------------------------
        # DATABASE (OPTIONAL – SAFE)
        # -------------------------------
        if PSYCOPG_AVAILABLE:
            self.get_logger().info("✅ PostgreSQL support READY")
        else:
            self.get_logger().warn("⚠️ PostgreSQL NOT available. Semantic DB disabled.")

        self.get_logger().info("✅ Display ENABLED")

    def image_callback(self, msg):
        if not TORCH_AVAILABLE or self.model is None:
            return

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(str(e))
            return

        image_tensor = self.transform(frame)
        detections = self.model([image_tensor])[0]

        boxes = detections['boxes']
        labels = detections['labels']
        scores = detections['scores']

        for i in range(len(scores)):
            if scores[i] > 0.7:
                box = boxes[i].detach().cpu().numpy().astype(int)
                label = int(labels[i])
                score = float(scores[i])

                cv2.rectangle(frame,
                              (box[0], box[1]),
                              (box[2], box[3]),
                              (0, 255, 0), 2)

                text = f"ID:{label} {score:.2f}"
                cv2.putText(frame, text,
                            (box[0], box[1] - 10),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5, (0, 255, 0), 2)

        cv2.imshow("Detections", frame)
        cv2.waitKey(1)


def main():
    rclpy.init()
    node = ObjectDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
