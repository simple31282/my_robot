from setuptools import setup

package_name = 'object_detector'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='edwardak',
    maintainer_email='edwardak@todo.todo',
    description='Object detection node',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'object_detector = object_detector.object_detector:main',
        ],
    },
)
